/* Copyright (C) 2012 Bernhard Reutner-Fischer <uclibc@uclibc.org>
 *
 * Licensed under the LGPL v2.1+, see the file COPYING.LIB in this tarball.
 */

#define L_rpmatch
#include "stdlib.c"
