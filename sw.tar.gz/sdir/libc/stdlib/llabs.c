/* Copyright (C) 2004-2006 Manuel Novoa III <mjn3@uclibc.org>
 *
 * Licensed under the LGPL v2.1, see the file COPYING.LIB in this tarball.
 */

#define L_llabs
#include "stdlib.c"
