/* Name of libgcc_s library provided by gcc.  */
#if defined(__m68k__)
#define LIBGCC_S_SO "libgcc_s.so.2"
#else
#define LIBGCC_S_SO "libgcc_s.so.1"
#endif
